RPG Character Battle System - COSC 102 Assignment 2

Extract all java files from the zip folder. Add all the java files into a new folder.
Open your IDE of choice, and select the folder that contains all the java files.
Open Main.java and Run java.

Enjoy!